"""Explicit stack formats. No implicit resampling, phase wrapping, or pickle."""
from pathlib import Path
import csv
import json
import numpy as np
from .core import Stack, date_string


def _raster(path, band=1):
    import rasterio
    with rasterio.open(path) as src:
        a = src.read(band, masked=True).astype(np.float64).filled(np.nan)
        meta = {"crs": src.crs.to_string() if src.crs else None,
                "transform": list(src.transform)[:6], "shape": list(a.shape)}
    return a, meta


def _same_grid(a, b):
    if a.get("shape") != b.get("shape") or a.get("crs") != b.get("crs") or not np.allclose(a.get("transform", []), b.get("transform", []), atol=1e-9, rtol=0):
        raise ValueError("栅格坐标系、尺寸或像元网格不同；请先统一网格，程序不会自动重采样相位。")


def load_stack(path):
    path = Path(path).resolve()
    if path.suffix.lower() == ".npz":
        with np.load(path, allow_pickle=False) as z:
            metadata = json.loads(str(z["metadata"])) if "metadata" in z else {}
            return Stack(dates=z["dates"].tolist(), pairs=z["pairs"].tolist(),
                         values=z["values"], coherence=z["coherence"],
                         unit=str(z["unit"]) if "unit" in z else "radian",
                         wavelength_m=float(z["wavelength_m"]) if "wavelength_m" in z else 0.05546576,
                         phase_sign=int(z["phase_sign"]) if "phase_sign" in z else -1,
                         mask=z["mask"] if "mask" in z else None, metadata=metadata,
                         components=z["components"] if "components" in z else None)
    if path.suffix.lower() in (".h5", ".hdf5"):
        import h5py
        with h5py.File(path, "r") as f:
            required = {"date", "unwrapPhase", "coherence"}
            if not required.issubset(f):
                raise ValueError("请选择 MintPy inputs/ifgramStack.h5，不能把 timeseries.h5 当作干涉栈。")
            keep = f["dropIfgram"][:].astype(bool) if "dropIfgram" in f else np.ones(len(f["date"]), bool)
            pairs = [[date_string(v) for v in row] for row in f["date"][:][keep]]
            attrs = dict(f.attrs)
            if "WAVELENGTH" not in attrs:
                raise ValueError("HDF5 缺少 WAVELENGTH 元数据，请使用明确波长的 NPZ/JSON 输入。")
            meta = {"source": str(path), "coordinate_system": "radar"}
            if all(k in attrs for k in ("X_FIRST", "Y_FIRST", "X_STEP", "Y_STEP")):
                x, y, dx, dy = [float(attrs[k]) for k in ("X_FIRST", "Y_FIRST", "X_STEP", "Y_STEP")]
                # MintPy X/Y_FIRST use GDAL upper-left corner conventions.
                unit = attrs.get("X_UNIT", "degrees")
                if isinstance(unit, bytes):
                    unit = unit.decode()
                if "deg" in str(unit).lower():
                    meta.update(crs="EPSG:4326", transform=[dx, 0, x, 0, dy, y], coordinate_system="geographic")
            values = f["unwrapPhase"][:][keep].astype(float)
            # MintPy native interferogram stacks use zero as no-data.
            values[values == 0] = np.nan
            return Stack(sorted({v for p in pairs for v in p}), pairs, values,
                         f["coherence"][:][keep], wavelength_m=float(attrs["WAVELENGTH"]),
                         metadata=meta, components=f["connectComponent"][:][keep] if "connectComponent" in f else None)
    if path.suffix.lower() != ".json":
        raise ValueError("输入格式为 .npz、.json 清单，或 MintPy ifgramStack.h5。")
    spec = json.loads(path.read_text(encoding="utf-8-sig"))
    if spec.get("unwrapped") is not True:
        raise ValueError("JSON 必须声明 unwrapped: true；缠绕相位不能直接做 SBAS。")
    values, coherence, components, pairs = [], [], [], []
    grid = None
    has_components = ["components" in p for p in spec["pairs"]]
    if any(has_components) and not all(has_components):
        raise ValueError("解缠连通分量需对全部干涉对提供。")
    for item in spec["pairs"]:
        def read(key, band=1):
            nonlocal grid
            p = (path.parent / item[key]).resolve()
            if p.suffix.lower() == ".npy":
                return np.load(p, allow_pickle=False).astype(float)
            arr, current = _raster(p, band)
            if grid is None:
                grid = current
            else:
                _same_grid(grid, current)
            return arr
        values.append(read("phase", int(item.get("phase_band", 1))))
        coherence.append(read("coherence", int(item.get("coherence_band", 1))))
        if "components" in item:
            components.append(read("components"))
        pairs.append((item["date1"], item["date2"]))
    metadata = dict(spec.get("metadata", {}))
    if grid:
        metadata.update(grid)
    mask = None
    if spec.get("mask"):
        p = path.parent / spec["mask"]
        if p.suffix.lower() == ".npy":
            mask = np.load(p, allow_pickle=False).astype(bool)
        else:
            arr, current = _raster(p)
            if grid:
                _same_grid(grid, current)
            mask = np.isfinite(arr) & (arr > 0)
    return Stack(sorted({date_string(v) for p in pairs for v in p}), pairs,
                 np.stack(values), np.stack(coherence), spec.get("unit", "radian"),
                 float(spec.get("wavelength_m", 0.05546576)), int(spec.get("phase_sign", -1)),
                 mask, metadata, np.stack(components) if components else None)


def save_stack(path, stack):
    stack.validate()
    extra = {}
    if stack.mask is not None:
        extra["mask"] = stack.mask
    if stack.components is not None:
        extra["components"] = stack.components
    np.savez_compressed(path, dates=np.array(stack.dates), pairs=np.array(stack.pairs),
                        values=stack.values.astype(np.float32), coherence=stack.coherence.astype(np.float32),
                        unit=np.array(stack.unit), wavelength_m=stack.wavelength_m,
                        phase_sign=stack.phase_sign, metadata=np.array(json.dumps(stack.metadata)), **extra)


def save_result(outdir, result, stack, threshold):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(outdir / "result.npz", **result, metadata=np.array(json.dumps(stack.metadata)))
    from .plots import save_plots
    save_plots(outdir, result, stack.metadata.get("synthetic", False))
    raster_status = "No geographic metadata; pixel-coordinate outputs only."
    if stack.metadata.get("crs") and stack.metadata.get("transform"):
        import rasterio
        from affine import Affine
        for key, name, unit in [("velocity_mm_year", "velocity.tif", "mm/year"),
                                ("displacement_mm", "displacement.tif", "mm"),
                                ("residual_mm", "residual.tif", "mm"),
                                ("temporal_coherence", "temporal_coherence.tif", "1")]:
            arr = result[key]
            if arr.ndim == 2:
                arr = arr[None]
            with rasterio.open(outdir / name, "w", driver="GTiff", height=arr.shape[1], width=arr.shape[2],
                               count=arr.shape[0], dtype="float32", crs=stack.metadata["crs"],
                               transform=Affine(*stack.metadata["transform"]), nodata=np.nan,
                               compress="deflate", BIGTIFF="IF_SAFER") as dst:
                dst.write(arr.astype(np.float32))
                dst.update_tags(units=unit, reference_yx=','.join(map(str, result["reference_yx"])),
                                los_positive="toward_satellite", synthetic=str(stack.metadata.get("synthetic", False)))
                if key == "displacement_mm":
                    for i, date in enumerate(result["dates"], 1):
                        dst.set_band_description(i, str(date))
        raster_status = "GeoTIFF exported on the input grid."
    valid = result["valid_mask"]
    v = result["velocity_mm_year"][valid]
    report = {"method": "weighted network least squares; coherence^2 heuristic weights",
              "synthetic": bool(stack.metadata.get("synthetic", False)),
              "epochs": len(stack.dates), "interferograms": len(stack.pairs),
              "reference_date": stack.dates[0], "reference_yx": result["reference_yx"].tolist(),
              "reference_selection": "User pixel or maximum minimum coherence; stability must be checked by user.",
              "threshold": threshold, "wavelength_m": stack.wavelength_m, "phase_sign": stack.phase_sign,
              "units": {"displacement": "mm", "velocity": "mm/year", "residual": "mm"},
              "los_positive": "toward satellite (requires source phase sign confirmation)",
              "valid_pixels": int(valid.sum()), "total_pixels": int(valid.size),
              "velocity_range_mm_year": [float(v.min()), float(v.max())] if len(v) else None,
              "raster_export": raster_status,
              "limitations": ["No atmospheric, residual DEM, orbital ramp, or unwrapping-error correction in lightweight solver.",
                              "Disconnected local networks are masked, not interpolated.",
                              "Residual and temporal coherence do not establish geophysical accuracy.",
                              "Large stacks are loaded into memory; use MintPy for production-scale processing."]}
    (outdir / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def export_point(result, row, col, path):
    ts = result["displacement_mm"]
    if not (0 <= row < ts.shape[1] and 0 <= col < ts.shape[2]):
        raise ValueError("像素坐标超出范围。")
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "relative_los_displacement_mm", "row", "col"])
        for date, value in zip(result["dates"], ts[:, row, col]):
            writer.writerow([str(date), float(value), row, col])
