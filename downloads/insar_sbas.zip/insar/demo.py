from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
from .core import Stack, select_pairs
from .io import save_stack


def create_demo(outdir, seed=42):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    offsets = [0, 12, 24, 36, 60, 72, 96, 108, 132, 156, 180, 204]
    dates = [(datetime(2024, 1, 1) + timedelta(days=d)).strftime("%Y%m%d") for d in offsets]
    pairs = select_pairs(dates, max_days=48)
    h, w = 96, 120
    yy, xx = np.mgrid[:h, :w]
    bowl = np.exp(-((xx-68)**2/25**2 + (yy-52)**2/19**2))
    velocity = -48 * bowl + 9 * np.exp(-((xx-28)**2+(yy-32)**2)/15**2)
    t = np.array(offsets) / 365.25
    truth = t[:, None, None] * velocity + 2 * np.sin(2*np.pi*t[:, None, None]) * bowl
    truth -= truth[:, 5:6, 5:6]
    wave = 0.05546576
    index = {d: i for i, d in enumerate(dates)}
    values = np.array([-(truth[index[q]]-truth[index[p]]) * 4*np.pi / (wave*1000) for p, q in pairs])
    values += rng.normal(0, 0.025, values.shape)
    coherence = rng.uniform(0.65, 0.95, values.shape)
    coherence[:, 5, 5] = 0.99
    coherence[:, 72:84, 10:35] = 0.12
    values[:, :3] = np.nan
    metadata = {"synthetic": True, "description": "Simulated LOS deformation; not satellite observations.",
                "crs": "EPSG:4326", "transform": [0.0003, 0, 116.30, 0, -0.0003, 39.95]}
    stack = Stack(dates, pairs, values, coherence, wavelength_m=wave, metadata=metadata)
    save_stack(outdir / "stack.npz", stack)
    np.savez_compressed(outdir / "truth.npz", displacement_mm=truth, velocity_mm_year=velocity)
    return outdir / "stack.npz"
