from pathlib import Path
from datetime import datetime
import numpy as np


def result_figure(result, synthetic=False):
    from matplotlib.figure import Figure
    fig = Figure(figsize=(12, 7), constrained_layout=True)
    axes = fig.subplots(2, 2)
    layers = [("velocity_mm_year", "Relative LOS velocity", "mm/year", "RdBu_r"),
              ("displacement_mm", "Last epoch displacement", "mm", "RdBu_r"),
              ("temporal_coherence", "Temporal coherence (fit diagnostic)", "0-1", "viridis"),
              ("residual_mm", "Weighted interferogram residual", "mm", "magma")]
    for ax, (key, title, unit, cmap) in zip(axes.flat, layers):
        data = result[key][-1] if key == "displacement_mm" else result[key]
        kwargs = {}
        if cmap == "RdBu_r":
            finite = data[np.isfinite(data)]
            limit = max(float(np.percentile(np.abs(finite), 98)), 0.1) if len(finite) else 1
            kwargs.update(vmin=-limit, vmax=limit)
        elif key == "temporal_coherence":
            kwargs.update(vmin=0, vmax=1)
        im = ax.imshow(data, cmap=cmap, **kwargs)
        ry, rx = result["reference_yx"]
        ax.plot(rx, ry, "k+", ms=8)
        ax.set(title=title, xlabel="Column", ylabel="Row")
        fig.colorbar(im, ax=ax, label=unit, shrink=0.85)
    fig.suptitle(("SYNTHETIC DEMO — " if synthetic else "") + "SBAS | relative to first epoch and reference pixel")
    return fig


def save_plots(outdir, result, synthetic=False):
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure
    fig = result_figure(result, synthetic)
    FigureCanvasAgg(fig).print_png(str(Path(outdir) / "overview.png"))
    fig = Figure(figsize=(11, 4), constrained_layout=True)
    ax = fig.subplots()
    dates = [datetime.strptime(str(d), "%Y%m%d") for d in result["dates"]]
    idx = {str(d): i for i, d in enumerate(result["dates"])}
    for p, q in result["pairs"]:
        i, j = idx[str(p)], idx[str(q)]
        ax.plot([dates[i], dates[j]], [i, j], color="#9ec3d8", lw=1)
    ax.scatter(dates, range(len(dates)), color="#176487", zorder=3)
    ax.set(xlabel="Acquisition date", ylabel="Epoch index", title="Interferogram network (date connectivity)")
    FigureCanvasAgg(fig).print_png(str(Path(outdir) / "network.png"))
