"""Run without arguments for the Chinese desktop application."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from insar.core import invert, select_pairs
from insar.io import load_stack, save_result, export_point
from insar.demo import create_demo


def main(argv=None):
    p = argparse.ArgumentParser(description="InSAR SBAS：中文桌面界面 / 时序反演 / MintPy / ISCE2")
    sub = p.add_subparsers(dest="command")
    sub.add_parser("gui", help="启动中文界面")
    demo = sub.add_parser("demo", help="生成并反演模拟数据（不是真实卫星结果）")
    demo.add_argument("--out", default="demo_output")
    inv = sub.add_parser("invert", help="反演已解缠 NPZ、JSON 或 MintPy 干涉栈")
    inv.add_argument("input")
    inv.add_argument("--out", default="sbas_output")
    inv.add_argument("--coherence", type=float, default=0.35)
    inv.add_argument("--ref", type=int, nargs=2, metavar=("ROW", "COL"))
    inv.add_argument("--block-size", type=int, default=512)
    pair = sub.add_parser("pairs", help="按时间 / 垂直基线选择连通干涉网络")
    pair.add_argument("input", help="JSON: dates 数组及可选 baselines_m 字典")
    pair.add_argument("--max-days", type=float, default=48)
    pair.add_argument("--max-perp", type=float, default=150)
    pair.add_argument("--out", default="pairs.csv")
    point = sub.add_parser("point", help="从 result.npz 导出单点时序")
    point.add_argument("input")
    point.add_argument("--yx", type=int, nargs=2, required=True)
    point.add_argument("--out", default="point.csv")
    search = sub.add_parser("search", help="检索 ASF Sentinel-1 IW SLC 元数据")
    search.add_argument("--bbox", type=float, nargs=4, required=True, metavar=("WEST", "SOUTH", "EAST", "NORTH"))
    search.add_argument("--start", required=True)
    search.add_argument("--end", required=True)
    search.add_argument("--track", type=int)
    search.add_argument("--direction", choices=["ASCENDING", "DESCENDING"])
    search.add_argument("--limit", type=int, default=500)
    search.add_argument("--out", default="scene_catalog")
    mint = sub.add_parser("mintpy", help="用当前环境中的 MintPy 执行完整时序流程")
    mint.add_argument("template")
    mint.add_argument("--out", default="mintpy_output")
    templ = sub.add_parser("mintpy-template", help="为 ISCE2 topsStack 成果生成 MintPy 配置")
    templ.add_argument("--root", required=True)
    templ.add_argument("--out", default="project.cfg")
    templ.add_argument("--ref", type=int, nargs=2)
    raw = sub.add_parser("raw", help="规划 / 执行 ISCE2 SLC -> MintPy SBAS 流程")
    raw.add_argument("config")
    raw.add_argument("--execute", action="store_true", help="在 Linux/WSL2 中实际执行外部处理")
    args = p.parse_args(argv)
    if args.command in (None, "gui"):
        from insar.gui import launch
        launch()
    elif args.command in ("demo", "invert"):
        source = create_demo(Path(args.out) / "input") if args.command == "demo" else args.input
        stack = load_stack(source)
        threshold = getattr(args, "coherence", 0.35)
        result = invert(stack, threshold, getattr(args, "ref", None), getattr(args, "block_size", 512),
                        lambda f, s: print(s) if f == 1 else None)
        report = save_result(args.out, result, stack, threshold)
        export_point(result, 52 if args.command == "demo" else int(result["reference_yx"][0]),
                     68 if args.command == "demo" else int(result["reference_yx"][1]), Path(args.out) / "point.csv")
        print(json.dumps(report, ensure_ascii=False, indent=2))
    elif args.command == "pairs":
        import csv
        spec = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
        pairs = select_pairs(spec["dates"], spec.get("baselines_m"), args.max_days, args.max_perp)
        with Path(args.out).open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["date1", "date2"])
            writer.writerows(pairs)
        if "baselines_m" not in spec:
            print("未提供垂直基线：仅按时间筛选，尚未验证空间小基线。")
        print(f"连通网络: {len(pairs)} 对 -> {Path(args.out).resolve()}")
    elif args.command == "point":
        with np.load(args.input, allow_pickle=False) as z:
            export_point(z, *args.yx, args.out)
    else:
        from insar import backends
        if args.command == "search":
            print(json.dumps(backends.search_scenes(args.bbox, args.start, args.end, args.out,
                                                    args.track, args.direction, args.limit), ensure_ascii=False, indent=2))
        elif args.command == "mintpy":
            backends.run_mintpy(args.template, args.out)
        elif args.command == "mintpy-template":
            print(backends.mintpy_template(args.root, args.out, ref_yx=args.ref))
        elif args.command == "raw":
            backends.raw_workflow(args.config, args.execute)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, FileNotFoundError, ImportError) as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)
