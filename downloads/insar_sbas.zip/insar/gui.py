"""Chinese Tkinter interface for the local InSAR SBAS toolkit."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

from .core import invert
from .io import export_point, load_stack, save_result


class InSARApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("InSAR SBAS 形变时序分析")
        self.root.geometry("900x690")
        self.root.minsize(760, 580)
        self.events: queue.Queue = queue.Queue()
        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar(value=str(Path.cwd() / "sbas_output"))
        self.threshold = tk.StringVar(value="0.35")
        self.reference = tk.StringVar()
        self.status = tk.StringVar(value="请选择解缠干涉栈文件开始处理。")
        self._build()
        self.root.after(150, self._drain_events)

    def _build(self):
        shell = ttk.Frame(self.root, padding=18)
        shell.pack(fill="both", expand=True)
        ttk.Label(shell, text="InSAR SBAS 形变时序分析", font=("Microsoft YaHei UI", 19, "bold")).pack(anchor="w")
        ttk.Label(shell, text="本地解算解缠干涉栈，查看 LOS 位移与速度；也可使用 MintPy / ISCE2 完成生产流程。",
                  wraplength=820).pack(anchor="w", pady=(5, 14))

        tabs = ttk.Notebook(shell)
        tabs.pack(fill="both", expand=True)
        self._build_invert_tab(tabs)
        self._build_scene_tab(tabs)
        self._build_pipeline_tab(tabs)

        footer = ttk.Frame(shell)
        footer.pack(fill="x", pady=(10, 0))
        ttk.Label(footer, textvariable=self.status, wraplength=680).pack(side="left", fill="x", expand=True)
        ttk.Button(footer, text="打开输出目录", command=self._open_output).pack(side="right")

    def _build_invert_tab(self, tabs):
        frame = ttk.Frame(tabs, padding=16)
        tabs.add(frame, text="时序反演")
        self._file_row(frame, "干涉栈", self.input_path, self._choose_stack,
                       "支持 .npz、.json 清单或 MintPy inputs/ifgramStack.h5")
        self._file_row(frame, "输出目录", self.output_path, self._choose_output, "结果包括 GeoTIFF（有地理参考时）、CSV、PNG 和 JSON")
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=7)
        ttk.Label(row, text="相干性阈值", width=16).pack(side="left")
        ttk.Entry(row, textvariable=self.threshold, width=12).pack(side="left")
        ttk.Label(row, text="参考像素（行,列；留空自动选高相干公共点）").pack(side="left", padx=(16, 6))
        ttk.Entry(row, textvariable=self.reference, width=16).pack(side="left")
        ttk.Button(frame, text="开始 SBAS 反演", command=self._start_invert).pack(anchor="w", pady=(12, 10))
        self.progress = ttk.Progressbar(frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=5)
        self.log = tk.Text(frame, height=15, wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True, pady=(8, 0))
        ttk.Label(frame, text="单位为相对 LOS 毫米与毫米/年。真实解算要求各干涉图相位已解缠、网格一致且相位符号/波长正确。",
                  wraplength=800).pack(anchor="w", pady=(9, 0))

    def _build_scene_tab(self, tabs):
        frame = ttk.Frame(tabs, padding=16)
        tabs.add(frame, text="Sentinel-1 检索")
        self.bbox = [tk.StringVar(value=v) for v in ("116.2", "39.7", "116.6", "40.1")]
        self.start_date = tk.StringVar(value="2024-01-01")
        self.end_date = tk.StringVar(value="2024-12-31")
        self.track = tk.StringVar()
        self.direction = tk.StringVar(value="任意")
        self.catalog_dir = tk.StringVar(value=str(Path.cwd() / "scene_catalog"))
        ttk.Label(frame, text="查询 ASF 上可用的 Sentinel-1 IW SLC 元数据，导出 CSV 与 GeoJSON。此步骤不会下载影像。",
                  wraplength=800).pack(anchor="w", pady=(0, 12))
        row = ttk.Frame(frame); row.pack(fill="x", pady=5)
        ttk.Label(row, text="范围 W,S,E,N", width=16).pack(side="left")
        for var in self.bbox: ttk.Entry(row, textvariable=var, width=12).pack(side="left", padx=3)
        self._simple_row(frame, "起止日期", self.start_date, self.end_date)
        row = ttk.Frame(frame); row.pack(fill="x", pady=5)
        ttk.Label(row, text="相对轨道号", width=16).pack(side="left")
        ttk.Entry(row, textvariable=self.track, width=12).pack(side="left")
        ttk.Label(row, text="飞行方向").pack(side="left", padx=(20, 6))
        ttk.Combobox(row, textvariable=self.direction, values=("任意", "ASCENDING", "DESCENDING"),
                     state="readonly", width=16).pack(side="left")
        self._file_row(frame, "导出目录", self.catalog_dir, self._choose_catalog, "")
        ttk.Button(frame, text="检索场景", command=self._search).pack(anchor="w", pady=12)

    def _build_pipeline_tab(self, tabs):
        frame = ttk.Frame(tabs, padding=16)
        tabs.add(frame, text="MintPy / ISCE2")
        ttk.Label(frame, text="原始 SLC 全流程需要 Linux/WSL2 中配置好的 ISCE2、SNAPHU 和 MintPy。此处提供 MintPy 启动与配置模板，以及 ISCE2 工作流规划。",
                  wraplength=800).pack(anchor="w", pady=(0, 12))
        self.mint_template = tk.StringVar()
        self.mint_out = tk.StringVar(value=str(Path.cwd() / "mintpy_output"))
        self.raw_config = tk.StringVar()
        self._file_row(frame, "MintPy 配置", self.mint_template, lambda: self._choose_file(self.mint_template, "配置文件", "*.cfg"), "smallbaselineApp 配置文件")
        self._file_row(frame, "MintPy 输出", self.mint_out, lambda: self._choose_dir(self.mint_out), "")
        row = ttk.Frame(frame); row.pack(fill="x", pady=(4, 14))
        ttk.Button(row, text="运行 MintPy", command=self._run_mintpy).pack(side="left")
        ttk.Button(row, text="生成 MintPy 配置模板", command=self._make_template).pack(side="left", padx=8)
        ttk.Separator(frame).pack(fill="x", pady=8)
        self._file_row(frame, "原始数据配置", self.raw_config,
                       lambda: self._choose_file(self.raw_config, "工作流 JSON", "*.json"),
                       "配置需填写本机已有的 SLC、DEM、轨道和辅助数据目录")
        row = ttk.Frame(frame); row.pack(fill="x", pady=7)
        ttk.Button(row, text="生成处理计划", command=self._plan_raw).pack(side="left")
        ttk.Button(row, text="执行原始 SLC 流程", command=self._execute_raw).pack(side="left", padx=8)
        ttk.Label(frame, text="执行原始数据处理会调用 ISCE2 的 stackSentinel.py 与 MintPy，并在配置工作目录创建处理文件和日志。",
                  wraplength=800).pack(anchor="w", pady=(12, 0))

    def _file_row(self, parent, label, variable, command, hint):
        row = ttk.Frame(parent); row.pack(fill="x", pady=6)
        ttk.Label(row, text=label, width=16).pack(side="left")
        ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="浏览…", command=command).pack(side="left", padx=(6, 0))
        if hint: ttk.Label(parent, text=hint).pack(anchor="w", padx=(128, 0))

    def _simple_row(self, parent, label, first, second):
        row = ttk.Frame(parent); row.pack(fill="x", pady=5)
        ttk.Label(row, text=label, width=16).pack(side="left")
        ttk.Entry(row, textvariable=first, width=18).pack(side="left")
        ttk.Label(row, text="至").pack(side="left", padx=7)
        ttk.Entry(row, textvariable=second, width=18).pack(side="left")

    def _choose_file(self, variable, title, pattern):
        p = filedialog.askopenfilename(title=title, filetypes=[(title, pattern), ("所有文件", "*.*")])
        if p: variable.set(p)

    def _choose_dir(self, variable):
        p = filedialog.askdirectory()
        if p: variable.set(p)

    def _choose_stack(self):
        self._choose_file(self.input_path, "选择解缠干涉栈", "*.npz *.json *.h5 *.hdf5")

    def _choose_output(self): self._choose_dir(self.output_path)
    def _choose_catalog(self): self._choose_dir(self.catalog_dir)

    def _log(self, message):
        self.log.configure(state="normal")
        self.log.insert("end", message + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.status.set(message)

    def _background(self, task):
        def run():
            try: task()
            except Exception as exc: self.events.put(("error", str(exc)))
        threading.Thread(target=run, daemon=True).start()

    def _drain_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "progress":
                    fraction, message = payload
                    self.progress["value"] = fraction * 100
                    self.status.set(message)
                elif kind == "log": self._log(payload)
                elif kind == "set": payload[0].set(payload[1])
                elif kind == "done":
                    self.progress["value"] = 100
                    self._log(payload)
                    messagebox.showinfo("完成", payload)
                elif kind == "error":
                    self._log("错误：" + payload)
                    messagebox.showerror("处理失败", payload)
        except queue.Empty: pass
        self.root.after(150, self._drain_events)

    def _start_invert(self):
        try:
            source, output = Path(self.input_path.get()), Path(self.output_path.get())
            threshold = float(self.threshold.get())
            ref = tuple(map(int, self.reference.get().split(","))) if self.reference.get().strip() else None
            if ref is not None and len(ref) != 2: raise ValueError("参考像素格式应为 行,列。")
            if not source.is_file(): raise ValueError("请先选择有效的干涉栈文件。")
            self.progress["value"] = 0
            self._log("读取干涉栈…")
        except Exception as exc:
            messagebox.showerror("参数错误", str(exc)); return
        def task():
            stack = load_stack(source)
            self.events.put(("log", f"已载入 {len(stack.dates)} 期、{len(stack.pairs)} 对，影像大小 {stack.values.shape[1:]}。"))
            result = invert(stack, threshold, ref, progress=lambda f, m: self.events.put(("progress", (f, m))))
            report = save_result(output, result, stack, threshold)
            export_point(result, *map(int, result["reference_yx"]), output / "reference_point.csv")
            self.events.put(("done", f"SBAS 反演完成：{output.resolve()}\n有效像元 {report['valid_pixels']} / {report['total_pixels']}。"))
        self._background(task)

    def _search(self):
        try:
            bbox = [float(v.get()) for v in self.bbox]
            track = int(self.track.get()) if self.track.get().strip() else None
            direction = self.direction.get() if self.direction.get() != "任意" else None
            start, end, catalog_dir = self.start_date.get(), self.end_date.get(), self.catalog_dir.get()
        except ValueError:
            messagebox.showerror("参数错误", "范围和轨道号需填写数字。"); return
        def task():
            from .backends import search_scenes
            summary = search_scenes(bbox, start, end, catalog_dir, track, direction)
            self.events.put(("done", f"检索完成：{summary['count']} 景。结果保存至 {Path(catalog_dir).resolve()}"))
        self._background(task)

    def _make_template(self):
        root = filedialog.askdirectory(title="选择 ISCE2 topsStack 输出目录")
        if not root: return
        target = filedialog.asksaveasfilename(title="保存 MintPy 配置", defaultextension=".cfg", initialfile="project.cfg")
        if not target: return
        def task():
            from .backends import mintpy_template
            result = mintpy_template(root, target)
            self.events.put(("set", (self.mint_template, str(result))))
            self.events.put(("done", f"MintPy 配置模板已生成：{result}。请检查数据路径与参考点后再运行。"))
        self._background(task)

    def _run_mintpy(self):
        template, outdir = self.mint_template.get(), self.mint_out.get()
        if not template:
            messagebox.showerror("缺少配置", "请选择 MintPy 配置文件。"); return
        def task():
            from .backends import run_mintpy
            run_mintpy(template, outdir, lambda m: self.events.put(("log", m)))
            self.events.put(("done", f"MintPy 处理完成：{Path(outdir).resolve()}"))
        self._background(task)

    def _plan_raw(self): self._raw(False)

    def _execute_raw(self):
        if not messagebox.askyesno("确认执行", "将调用 ISCE2 与 MintPy 运行完整原始 SLC 处理，并写入配置中的工作目录。继续吗？"):
            return
        self._raw(True)

    def _raw(self, execute):
        config = self.raw_config.get()
        if not config:
            messagebox.showerror("缺少配置", "请选择原始数据工作流 JSON。"); return
        def task():
            from .backends import raw_workflow
            plan = raw_workflow(config, execute,
                                lambda m: self.events.put(("log", m)))
            label = "原始 SLC 工作流完成" if execute else "处理计划已写入"
            self.events.put(("done", f"{label}：{plan['working_directory']}\\workflow_plan.json"))
        self._background(task)

    def _open_output(self):
        path = Path(self.output_path.get())
        if not path.exists():
            messagebox.showinfo("输出目录", f"目录尚未创建：{path}"); return
        import os, subprocess
        if os.name == "nt": os.startfile(path)
        else: subprocess.Popen(["xdg-open", str(path)])


def launch():
    root = tk.Tk()
    InSARApp(root)
    root.mainloop()
