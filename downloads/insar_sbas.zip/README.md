# InSAR SBAS 工具箱

这是一个本地 Python 桌面工具和命令行程序，用于 Sentinel-1 时序 InSAR 工作。它包含轻量 SBAS 加权最小二乘反演、ASF Sentinel-1 SLC 元数据检索，以及调用 ISCE2 topsStack 和 MintPy 的工作流入口。

## 先了解它能处理什么

时序反演需要**已经配准并解缠**的干涉图，以及逐像元相干性；支持 MintPy `inputs/ifgramStack.h5`、本工具 `.npz` 栈和栅格 `.json` 清单。程序会解算相对 LOS 位移、线性速度、加权残差和时序相干性，并在输入包含坐标参考信息时导出 GeoTIFF。

从原始 Sentinel-1 SLC 到干涉栈的全流程由官方 ISCE2/MintPy 引擎完成。本工具可检索 ASF 元数据、生成 ISCE2/MintPy 项目计划和 MintPy 配置，也能在已配置好的 Linux/WSL2 环境中启动处理。它不会把原始 SLC 直接交给轻量 SBAS 求解器，也不会将模拟数据当作真实卫星结果。

轻量反演页采用相干性平方作为加权启发式，不包含大气延迟、残余地形相位或解缠错误校正。原始 SLC 流程调用 ISCE2 topsStack 与 MintPy，可生成/运行解缠错误、对流层延迟和 DEM 残差改正步骤。结果是相对于参考点和首期的 LOS 测量，不等于绝对地表运动，也不能单独作为工程安全结论。

## 安装

Python 3.10–3.12。Windows 可运行桌面界面、元数据检索及已有干涉栈反演；原始 SLC 的 ISCE2 处理请使用 Linux 或 WSL2。

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

`tkinter` 通常随 Python 安装提供。`asf_search` 用于在线检索，需要网络连接；若只运行 `.npz`/栅格栈反演，无需 ASF 账户。

## 启动桌面界面

```powershell
python main.py
```

也可明确运行 `python main.py gui`。界面各页包括：

- **时序反演**：读取解缠干涉栈，设置相干性阈值和公共参考像素。
- **Sentinel-1 检索**：按经纬度框、日期、相对轨道和飞行方向查询 ASF SLC 场景，并导出 CSV/GeoJSON。查询是数据目录检索，不会下载影像。
- **MintPy / ISCE2**：运行已有 MintPy 配置，或在工作流表单选择本机 SLC、DEM、AOI、轨道与辅助目录，生成计划并启动原始数据流程；也可设置解缠错误、大气延迟、DEM 残差、去坡度和排除日期。表单可保存/载入 JSON 配置。

## 命令行示例

生成一组**模拟**干涉数据并运行反演：

```powershell
python main.py demo --out demo_output
```

对已有干涉栈运行反演：

```powershell
python main.py invert path/to/ifgramStack.h5 --out result --coherence 0.35
```

检索 ASF 上的 Sentinel-1 IW SLC 元数据（框坐标顺序：西、南、东、北）：

```powershell
python main.py search --bbox 116.2 39.7 116.6 40.1 --start 2024-01-01 --end 2024-12-31 --direction ASCENDING --out scene_catalog
```

生成 MintPy 配置模板：

```powershell
python main.py mintpy-template --root /data/isce/topsStack --out project.cfg
python main.py mintpy project.cfg --out mintpy_output
```

模拟数据只能检查软件流程和图表是否生成，不能用于地表形变解释。

## 支持的输入

1. **MintPy HDF5**：`inputs/ifgramStack.h5`，需要 `date`、`unwrapPhase`、`coherence` 数据集和 `WAVELENGTH` 属性。程序按 MintPy 栈约定把零相位值视作无数据。
2. **NPZ 栈**：至少含 `dates`（`YYYYMMDD`）、`pairs`（日期对）、`values`、`coherence`；`values` 形状为 `[干涉对, 行, 列]`。可选字段有 `unit`（`radian`、`mm`、`m`）、`wavelength_m`、`phase_sign`、`mask`、`components` 和 `metadata`。默认相位单位为弧度、C 波段波长约 0.05547 m、相位到 LOS 的符号为 -1；请根据源数据确认符号。
3. **JSON 栅格清单**：适合 GeoTIFF/NumPy 栅格。下面给出格式示例：

参考 `examples/stack_manifest.example.json`。清单中至少要有三期、连通的干涉网络。

将路径相对于清单文件填写。所有栅格必须使用同一 CRS、尺寸和像元网格；程序会拒绝不一致输入，不会暗中重采样。若传入连通分量栅格，程序会使用公共参考点所在的连通分量。至少需要三期且干涉网络必须连通。

## 原始 SLC 工作流配置

桌面界面的 MintPy / ISCE2 页可直接填写输入；也可按 `examples/raw_project.example.json` 准备配置。SLC 目录应包含同一轨道、同一方向的 Sentinel-1 IW `.SAFE` 或产品 `.zip`；DEM 使用适合 ISCE2 的 WGS84 椭球高数据，并提供 ISCE2 所需的 XML sidecar。工作流生成 `workflow_plan.json` 和显式列出校正选项的 MintPy 配置；Windows 执行会通过 WSL 启动 Linux 命令，Linux 原生环境会直接运行。

原始 SLC 处理需要 Linux/WSL2、ISCE2 `topsStack`、SNAPHU 与 MintPy。Windows 首次使用需安装 WSL2 和 Ubuntu，并在 Linux 环境按上游项目文档安装处理引擎；本程序不会静默下载/安装数 GB 的依赖。ISCE2 先生成 `run_files`，然后按编号运行 TOPS stack 步骤；MintPy 负责网络反演、误差改正、质量评估和地理编码。

工作流默认启用 MintPy `bridging+phase_closure` 解缠错误改正和 `height_correlation` 对流层改正、残余 DEM 改正；解缠错误步骤要求输入包含 SNAPHU 连通分量。ERA5 (`pyaps`) 需要额外安装 PyAPS 并访问/获取天气数据，GACOS 与 OPERA 需要预先准备对应延迟产品。去坡度默认为关闭：MintPy 文档说明它适合局部形变，但可能移除地震等长波长信号。根据研究目标核对参考点、连通网络和改正结果。

## 输出

反演结果目录包括 `result.npz`、`report.json`、`overview.png`、`network.png`、参考点时序 CSV；若输入带 CRS 与 affine transform，也导出速度、位移、残差和时序相干性 GeoTIFF。输出指标包含内部拟合质量检查，不是独立的地面真值验证。

## 相关开源项目

- [MintPy](https://github.com/insarlab/MintPy)：成熟的 InSAR 时间序列分析软件，可读取 ISCE、ARIA、FRInGE、HyP3、GMTSAR 等处理栈并运行 SBAS。
- [EO-Tools](https://github.com/odhondt/eo_tools)：Python Sentinel-1 工具箱，可检索、下载和处理 Sentinel-1 干涉对，也提供 AOI 范围内的部分产品下载。
- [ISCE2](https://github.com/isce-framework/isce2)：SAR/InSAR 处理框架；本工具通过其 topsStack 脚本处理原始 SLC。
- [Friendly-InSAR-time-series](https://github.com/UW-GDA/Friendly-InSAR-time-series)：另一个将 ISCE2 topsStack 和 MintPy 串联起来的开源 Sentinel-1 时序工作流，可作为操作流程参考。

本工具是独立实现的轻量分析界面，不包含上述项目的代码。算法说明与适用限制见本文件和结果目录中的 `report.json`。
