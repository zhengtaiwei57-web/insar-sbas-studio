"""Use established upstream engines for raw SLC processing and corrections."""
from pathlib import Path
from datetime import date
import csv
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys


def mintpy_template(root, output, max_days=48, max_perp=150, ref_yx=None):
    root = Path(root).resolve().as_posix()
    lines = {"mintpy.load.processor": "isce",
             "mintpy.load.metaFile": f"{root}/reference/IW*.xml",
             "mintpy.load.baselineDir": f"{root}/baselines",
             "mintpy.load.unwFile": f"{root}/merged/interferograms/*/filt_*.unw",
             "mintpy.load.corFile": f"{root}/merged/interferograms/*/filt_*.cor",
             "mintpy.load.connCompFile": f"{root}/merged/interferograms/*/filt_*.unw.conncomp",
             "mintpy.load.demFile": f"{root}/merged/geom_reference/hgt.rdr",
             "mintpy.load.lookupYFile": f"{root}/merged/geom_reference/lat.rdr",
             "mintpy.load.lookupXFile": f"{root}/merged/geom_reference/lon.rdr",
             "mintpy.load.incAngleFile": f"{root}/merged/geom_reference/los.rdr",
             "mintpy.load.azAngleFile": f"{root}/merged/geom_reference/los.rdr",
             "mintpy.load.shadowMaskFile": f"{root}/merged/geom_reference/shadowMask.rdr",
             "mintpy.network.tempBaseMax": max_days,
             "mintpy.network.perpBaseMax": max_perp,
             "mintpy.reference.date": "auto"}
    if ref_yx is not None:
        lines["mintpy.reference.yx"] = f"{int(ref_yx[0])},{int(ref_yx[1])}"
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("# ISCE2 topsStack -> MintPy. Inspect network and reference before interpretation.\n"
                      + "\n".join(f"{k} = {v}" for k, v in lines.items()) + "\n", encoding="utf-8")
    return output.resolve()


def run_mintpy(template, outdir, emit=print):
    if importlib.util.find_spec("mintpy") is None:
        raise RuntimeError("当前 Python 环境未安装 MintPy。请按官方安装文档配置，然后用该环境运行。")
    template = Path(template).resolve()
    if not template.is_file():
        raise ValueError("MintPy 配置文件不存在。")
    outdir = Path(outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-m", "mintpy.cli.smallbaselineApp", str(template)]
    run_logged(command, outdir, outdir / "mintpy.log", emit)


def run_logged(command, cwd, logpath, emit=print):
    emit("执行: " + subprocess.list2cmdline(list(map(str, command))))
    with Path(logpath).open("w", encoding="utf-8") as log:
        with subprocess.Popen(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, encoding="utf-8", errors="replace", bufsize=1) as proc:
            for line in proc.stdout:
                log.write(line)
                log.flush()
                emit(line.rstrip())
            code = proc.wait()
    if code:
        raise RuntimeError(f"处理失败，退出码 {code}，日志: {logpath}")


def raw_workflow(config, execute=False, emit=print):
    """Build a concrete plan, or run ISCE2 numbered stages then MintPy."""
    config = Path(config).resolve()
    spec = json.loads(config.read_text(encoding="utf-8-sig"))
    def path(key):
        return (config.parent / spec[key]).resolve()
    root = path("work_dir")
    slc, dem, orbit, aux = (path(k) for k in ("slc_dir", "dem", "orbit_dir", "aux_dir"))
    if not slc.is_dir() or not dem.is_file():
        raise ValueError("请在 raw_project.json 填写已有的 SLC 目录和 WGS84 椭球高 DEM 文件。")
    if not list(slc.glob("*.SAFE")) and not list(slc.glob("*.zip")):
        raise ValueError("SLC 目录没有 .SAFE 或 .zip 数据；不能使用 GRD 代替 SLC。")
    bbox = spec["bbox_snwe"]
    if len(bbox) != 4:
        raise ValueError("bbox_snwe 顺序必须为 南、北、西、东。")
    south, north, west, east = map(float, bbox)
    if not (-90 <= south < north <= 90 and -180 <= west < east <= 180):
        raise ValueError("bbox_snwe 无效；跨日期变更线范围需拆分。")
    root.mkdir(parents=True, exist_ok=True)
    command = [spec.get("stack_sentinel", "stackSentinel.py"), "-s", str(slc), "-d", str(dem),
               "-o", str(orbit), "-a", str(aux), "-b", " ".join(map(str, bbox)),
               "-W", "interferogram", "-c", str(spec.get("connections", 3)),
               "-p", spec.get("polarization", "vv")]
    template = mintpy_template(root, root / "mintpy" / "project.cfg",
                               spec.get("max_days", 48), spec.get("max_perp_m", 150), spec.get("reference_yx"))
    plan = {"stack_command": command, "working_directory": str(root),
            "next_steps": ["Execute run_files/run_* in numeric order with bash", "Run MintPy smallbaselineApp"],
            "mintpy_template": str(template),
            "requirements": ["Linux/WSL2 with ISCE2 topsStack, SNAPHU and MintPy configured",
                             "Same-track IW SLCs covering common bursts; WGS84 ellipsoidal DEM and XML sidecar"]}
    (root / "workflow_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    emit(f"处理计划已保存: {root / 'workflow_plan.json'}")
    if not execute:
        return plan
    if os.name == "nt":
        raise RuntimeError("原始 SLC 流程请在 WSL2/Linux 的 ISCE2 环境运行。当前已生成计划和 MintPy 配置。")
    if not shutil.which(command[0]) and not Path(command[0]).is_file():
        raise RuntimeError("未找到 stackSentinel.py，请配置 ISCE2 topsStack 的 PATH/PYTHONPATH。")
    if shutil.which("bash") is None or importlib.util.find_spec("mintpy") is None:
        raise RuntimeError("缺少 bash 或当前 Python 环境缺少 MintPy。")
    if list((root / "run_files").glob("run_*")):
        raise RuntimeError("工作目录已有 run_files。请为新的处理选择空工作目录，避免覆盖或重复执行。")
    orbit.mkdir(parents=True, exist_ok=True)
    aux.mkdir(parents=True, exist_ok=True)
    run_logged(command, root, root / "isce_config.log", emit)
    runs = list((root / "run_files").glob("run_*"))
    if not runs or any(not re.match(r"run_\d+_", p.name) for p in runs):
        raise RuntimeError("未发现预期的 ISCE2 编号运行脚本，请查看 isce_config.log。")
    for run in sorted(runs, key=lambda p: int(re.match(r"run_(\d+)_", p.name)[1])):
        run_logged(["bash", str(run)], root, root / (run.name + ".log"), emit)
    run_mintpy(template, root / "mintpy", emit)
    return plan


def search_scenes(bbox, start, end, outdir, track=None, direction=None, limit=500):
    import asf_search as asf
    west, south, east, north = map(float, bbox)
    if not (-180 <= west < east <= 180 and -90 <= south < north <= 90):
        raise ValueError("bbox 顺序为 西、南、东、北，且不可跨日期变更线。")
    if date.fromisoformat(start) > date.fromisoformat(end):
        raise ValueError("起始日期不得晚于结束日期。")
    if not 1 <= limit <= 10000:
        raise ValueError("检索条数必须为 1～10000。")
    wkt = f"POLYGON(({west} {south},{east} {south},{east} {north},{west} {north},{west} {south}))"
    args = dict(platform=asf.PLATFORM.SENTINEL1, processingLevel="SLC", beamMode="IW",
                intersectsWith=wkt, start=start + "T00:00:00Z", end=end + "T23:59:59Z", maxResults=limit)
    if track is not None:
        args["relativeOrbit"] = int(track)
    if direction:
        args["flightDirection"] = direction.upper()
    results = asf.search(**args)
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    geojson = results.geojson()
    (outdir / "scenes.geojson").write_text(json.dumps(geojson, ensure_ascii=False, indent=2), encoding="utf-8")
    keys = ["sceneName", "startTime", "pathNumber", "frameNumber", "flightDirection", "polarization", "url"]
    with (outdir / "scenes.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for feature in geojson.get("features", []):
            writer.writerow({k: feature["properties"].get(k, "") for k in keys})
    groups = {}
    for feature in geojson.get("features", []):
        p = feature["properties"]
        key = f"track={p.get('pathNumber')}|direction={p.get('flightDirection')}|polarization={p.get('polarization')}"
        groups[key] = groups.get(key, 0) + 1
    summary = {"count": len(results), "possibly_truncated": len(results) >= limit, "groups": groups,
               "note": "Search intersects AOI; verify full coverage/common bursts. Never mix tracks or directions. No download or cloud job submitted."}
    (outdir / "search_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary
