# InSAR SBAS 工具箱

这是一个本地 Python 桌面工具和命令行程序，用于 Sentinel-1 时序 InSAR 工作。它包含轻量 SBAS 加权最小二乘反演、ASF Sentinel-1 SLC 元数据检索，以及调用 ISCE2 topsStack 和 MintPy 的工作流入口。

## 先了解它能处理什么

时序反演需要**已经配准并解缠**的干涉图，以及逐像元相干性；支持 MintPy `inputs/ifgramStack.h5`、本工具 `.npz` 栈和栅格 `.json` 清单。程序会解算相对 LOS 位移、线性速度、加权残差和时序相干性，并在输入包含坐标参考信息时导出 GeoTIFF。

从原始 Sentinel-1 SLC 到干涉栈的全流程由官方 ISCE2/MintPy 引擎完成。本工具可检索 ASF 元数据、生成 ISCE2/MintPy 项目计划和 MintPy 配置，也能在已配置好的 Linux/WSL2 环境中启动处理。它不会把原始 SLC 直接交给轻量 SBAS 求解器，也不会将模拟数据当作真实卫星结果。

本地算法采用相干性平方作为加权启发式；不包含大气延迟、残余地形相位、轨道坡面或解缠错误校正。结果是相对于参考点和首期的 LOS 测量，不等于绝对地表运动，也不能单独作为工程安全结论。大规模栈建议使用 MintPy 完整流程。

## 安装

Python 3.10–3.12。Windows 可运行桌面界面、元数据检索及已有干涉栈反演；原始 SLC 的 ISCE2 处理请使用 Linux 或 WSL2。

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

`tkinter` 通常随 Python 安装提供。`asf_search` 用于在线检索，需要网络连接；若只运行 `.npz`/栅格栈反演，无需 ASF 账户。

## 启动桌面界面

```powershell
python main.py
```

也可明确运行 `python main.py gui`。界面各页包括：

- **时序反演**：读取解缠干涉栈，设置相干性阈值和公共参考像素。
- **Sentinel-1 检索**：按经纬度框、日期、相对轨道和飞行方向查询 ASF SLC 场景，并导出 CSV/GeoJSON。查询是数据目录检索，不会下载影像。
- **MintPy / ISCE2**：运行已有 MintPy 配置、为 topsStack 结果生成模板，或规划/执行 ISCE2 原始 SLC 工作流。

## 命令行示例

生成一组**模拟**干涉数据并运行反演：

```powershell
python main.py demo --out demo_output
```

对已有干涉栈运行反演：

```powershell
python main.py invert path/to/ifgramStack.h5 --out result --coherence 0.35
```

检索 ASF 上的 Sentinel-1 IW SLC 元数据（框坐标顺序：西、南、东、北）：

```powershell
python main.py search --bbox 116.2 39.7 116.6 40.1 --start 2024-01-01 --end 2024-12-31 --direction ASCENDING --out scene_catalog
```

生成 MintPy 配置模板：

```powershell
python main.py mintpy-template --root /data/isce/topsStack --out project.cfg
python main.py mintpy project.cfg --out mintpy_output
```

模拟数据只能检查软件流程和图表是否生成，不能用于地表形变解释。

## 支持的输入

1. **MintPy HDF5**：`inputs/ifgramStack.h5`，需要 `date`、`unwrapPhase`、`coherence` 数据集和 `WAVELENGTH` 属性。程序按 MintPy 栈约定把零相位值视作无数据。
2. **NPZ 栈**：至少含 `dates`（`YYYYMMDD`）、`pairs`（日期对）、`values`、`coherence`；`values` 形状为 `[干涉对, 行, 列]`。可选字段有 `unit`（`radian`、`mm`、`m`）、`wavelength_m`、`phase_sign`、`mask`、`components` 和 `metadata`。默认相位单位为弧度、C 波段波长约 0.05547 m、相位到 LOS 的符号为 -1；请根据源数据确认符号。
3. **JSON 栅格清单**：适合 GeoTIFF/NumPy 栅格。下面给出格式示例：

参考 `examples/stack_manifest.example.json`。清单中至少要有三期、连通的干涉网络。

将路径相对于清单文件填写。所有栅格必须使用同一 CRS、尺寸和像元网格；程序会拒绝不一致输入，不会暗中重采样。若传入连通分量栅格，程序会使用公共参考点所在的连通分量。至少需要三期且干涉网络必须连通。

## 原始 SLC 工作流配置

先复制 `examples/raw_project.example.json`，按本机环境填写绝对路径和 AOI。SLC 目录应包含同一轨道、同一方向的 Sentinel-1 IW `.SAFE` 或产品 `.zip`；DEM 使用适合 ISCE2 的 WGS84 椭球高数据。计划模式会写出 `workflow_plan.json` 与 MintPy 配置；执行模式会调用已安装的 `stackSentinel.py`、ISCE2 编号脚本和 MintPy，并将日志保存在项目目录。首次运行前检查磁盘空间、路径和区域参数。

## 输出

反演结果目录包括 `result.npz`、`report.json`、`overview.png`、`network.png`、参考点时序 CSV；若输入带 CRS 与 affine transform，也导出速度、位移、残差和时序相干性 GeoTIFF。输出指标包含内部拟合质量检查，不是独立的地面真值验证。

## 相关开源项目

- [MintPy](https://github.com/insarlab/MintPy)：成熟的 InSAR 时间序列分析软件，可读取 ISCE、ARIA、FRInGE、HyP3、GMTSAR 等处理栈并运行 SBAS。
- [EO-Tools](https://github.com/odhondt/eo_tools)：Python Sentinel-1 工具箱，可检索、下载和处理 Sentinel-1 干涉对，也提供 AOI 范围内的部分产品下载。
- [ISCE2](https://github.com/isce-framework/isce2)：SAR/InSAR 处理框架；本工具通过其 topsStack 脚本处理原始 SLC。

本工具是独立实现的轻量分析界面，不包含上述项目的代码。算法说明与适用限制见本文件和结果目录中的 `report.json`。
